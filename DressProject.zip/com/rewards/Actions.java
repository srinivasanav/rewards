package com.rewards;

public interface Actions {
	 public static final int PUT_ON_FOOTWEAR = 1;
	 public static final int PUT_ON_HEADWEAR = 2;
	 public static final int PUT_ON_SOCKS = 3;
	 public static final int PUT_ON_SHIRT = 4;
	 public static final int PUT_ON_JACKET =5;
	 public static final int PUT_ON_PANTS = 6;
	 public static final int LEAVE_HOUSE = 7;
	 public static final int TAKE_OFF_PAJAMAS = 8;
	 public static final int MIN_LIMIT = 1;
	 public static final int MAX_LIMIT = 8;
	 public static final String HOT = "HOT ";
	 public static final String COLD = "COLD ";
}
